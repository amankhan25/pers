package com.spring.test.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.spring.entities.Coil;

public class CoilDaoImpl implements CoilDao {

	private JdbcTemplate jdbcTemplate;

	public Coil coilSource() {

		String query = "SELECT INV_SOURCE_CODE, COUNT(*) AS cnt FROM COIL_INVENTORY GROUP BY INV_SOURCE_CODE";
		RowMapper<Coil> rowMapper = new RowMapperImpl();
		Coil queryForObject = this.jdbcTemplate.queryForObject(query, rowMapper);
		return queryForObject;

	}

	public List<Coil> coilDate() {
		String query = "SELECT trunc(prod_datetime), COUNT(*) AS cnt FROM coil_inventory GROUP BY trunc(prod_datetime) ORDER BY trunc(prod_datetime)";
		RowMapper<Coil> rowMapper = new RowMapperImpl();
		List<Coil> querylist = this.jdbcTemplate.query(query, rowMapper);
		return querylist;
	}

	public List<Coil> coilSchedule() {
		String query = "SELECT pick_list.hsm_schd_no, COUNT(*) AS cnt FROM coil_inventory "
				+ "INNER JOIN pick_list ON coil_inventory.inv_id = pick_list.coil_no "
				+ "INNER JOIN slab_inventory ON pick_list.inv_id = slab_inventory.inv_id "
				+ "GROUP BY pick_list.hsm_schd_no ORDER BY pick_list.hsm_schd_no";
		RowMapper<Coil> rowMapper = new RowMapperImpl();
		List<Coil> querylist = this.jdbcTemplate.query(query, rowMapper);
		return querylist;
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

}

package com.spring.entities;

public class Coil {
	private String inventorySource;
	private String date;
	private int count;
	private int schedule;
	private int scheduleCount;

	public String getInventorySource() {
		return inventorySource;
	}

	public void setInventorySource(String inventorySource) {
		this.inventorySource = inventorySource;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public Coil() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getSchedule() {
		return schedule;
	}

	public void setSchedule(int schedule) {
		this.schedule = schedule;
	}

	public int getScheduleCount() {
		return scheduleCount;
	}

	public void setScheduleCount(int scheduleCount) {
		this.scheduleCount = scheduleCount;
	}

	public Coil(String inventorySource, String date, int count, int schedule, int scheduleCount) {
		super();
		this.inventorySource = inventorySource;
		this.date = date;
		this.count = count;
		this.schedule = schedule;
		this.scheduleCount = scheduleCount;
	}

	
}

package com.spring.entities;

public class Slab {
	private String date;
	private int count;
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public Slab() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Slab(String date, int count) {
		super();
		this.date = date;
		this.count = count;
	}
	@Override
	public String toString() {
		return "Slab [date=" + date + ", count=" + count + "]";
	}
}

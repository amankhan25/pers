package com.springcore.javaconfig;

public class Samosa {
	
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("My price is little bit high...");
	}
}

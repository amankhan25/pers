package com.springcore.lifecycle;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Burger {
	private String souce;

	@Override
	public String toString() {
		return "Burger [souce=" + souce + "]";
	}

	public Burger() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getSouce() {
		return souce;
	}

	public void setSouce(String souce) {
		this.souce = souce;
	}
	
	@PostConstruct
	public void start() {
		System.out.println("Starting Method");
	}
	@PreDestroy
	public void end() {
		System.out.println("Ending Method");
	}
}

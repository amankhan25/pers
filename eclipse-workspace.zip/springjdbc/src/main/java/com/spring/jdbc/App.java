package com.spring.jdbc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.spring.jdbc.dao.StudentDao;
import com.spring.jdbc.entities.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "My program started......." );
        //spring jdbc=> jdbcTemplate
        //ApplicationContext context = new ClassPathXmlApplicationContext("com/spring/jdbc/config.xml");
        ApplicationContext context = new AnnotationConfigApplicationContext(JdbcConfig.class);
//        JdbcTemplate template = context.getBean("jdbctemplate",JdbcTemplate.class);
//        
//        //Insert Query
//        String query = "insert into student(id,name,city) values(?,?,?)";
//        
//        //Fire Query
//        int result = template.update(query,457,"Avita", "Kanpur");
//        System.out.println("Number of record inserted.."+result);
        
        StudentDao studentDao = context.getBean("studentDao",StudentDao.class);
        
        //Insert
//        Student student = new Student();
//        student.setId(666);;
//        student.setName("John");
//        student.setCity("Lucknow");
//        
//        int insert = studentDao.insert(student);
//        System.out.println("Student Added: "+insert);
        
        //Update
//        Student student = new Student();
//        student.setName("Raj Kumar");
//        student.setCity("Jabalpur");
//        student.setId(666);
//        int result = studentDao.change(student);
//        System.out.println("Student Changed: "+result);

        //Delete
//        int delete = studentDao.delete(666);
//        System.out.println("Student Deleted: "+delete);
        
        //Select
        Student student = studentDao.selectStudent(456);
        System.out.println(student);
        
        //Select All
        List<Student> students = studentDao.selectAllStudent();
        for (Student s : students) {
			System.out.println(s);
		}        
    }
}

package springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import springmvc.model.User;

@Controller
public class ContactController {

	@RequestMapping("/contact")
	public String showForm() {
		return "contact";
	}

	/* Normal Old approach 
	@RequestMapping(path = "/processForm", method = RequestMethod.POST)
	public String handleForm(@RequestParam(name="email", required = true) String userEmail, @RequestParam("userName") String userName,
			@RequestParam("userPassword") String userPassword, Model model) {
		
		User user = new User();
		user.setEmail(userEmail);
		user.setUserName(userName);
		user.setUserPassword(userPassword );
		
		System.out.println("User Email "+ userEmail);
		System.out.println("User Name "+ userName);
		System.out.println("User Password "+ userPassword);
		
		//process
		
//		model.addAttribute("email",userEmail);
//		model.addAttribute("name",userName);
//		model.addAttribute("password",userPassword);
		model.addAttribute("user", user);
		
		return "success";
	}
	*/
	@RequestMapping(path="/processForm", method = RequestMethod.POST)
	public String handleForm(@ModelAttribute User user, Model model) {
		System.out.println(user);
		return "success";
	}

}

package com.spring.entities;

public class Coil {
	private String inventorySource;
	private String date;
	private int count;

	public String getInventorySource() {
		return inventorySource;
	}

	public void setInventorySource(String inventorySource) {
		this.inventorySource = inventorySource;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public Coil() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Coil(String inventorySource, String date, int count) {
		super();
		this.inventorySource = inventorySource;
		this.date = date;
		this.count = count;
	}

	@Override
	public String toString() {
		return "Coil [inventorySource=" + inventorySource + ", date=" + date + ", count=" + count + "]";
	}
}

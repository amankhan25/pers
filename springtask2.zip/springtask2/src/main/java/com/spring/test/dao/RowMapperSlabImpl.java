package com.spring.test.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.spring.entities.Slab;

public class RowMapperSlabImpl implements RowMapper<Slab> {

	public Slab mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Slab slab = new Slab();
		slab.setDate(rs.getString(1));
		slab.setCount(rs.getInt(2));
		return slab;
	}

}

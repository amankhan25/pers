package com.spring.test.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.spring.entities.Slab;

public class SlabDaoImpl implements SlabDao{
	
	private JdbcTemplate jdbcTemplate;
	
	public List<Slab> slabDate() {
		String query = "SELECT trunc(prod_datetime), COUNT(*) AS cnt FROM slab_inventory GROUP BY trunc(prod_datetime) ORDER BY trunc(prod_datetime)";
		RowMapper<Slab> rowMapperSlab = new RowMapperSlabImpl();
		List<Slab> queryDate = this.jdbcTemplate.query(query, rowMapperSlab);
		return queryDate;
	}
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

}

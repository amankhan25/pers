package com.spring.test.dao;

import java.util.List;

import com.spring.entities.Coil;

public interface CoilDao {
	public Coil coilSource();
	public List<Coil> coilDate();
}

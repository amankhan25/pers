package com.spring.test.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.spring.entities.Coil;

public class RowMapperImpl implements RowMapper<Coil> {

	public Coil mapRow(ResultSet rs, int rowNum) throws SQLException {
		Coil coil = new Coil();
		coil.setInventorySource(rs.getString(1));
		coil.setCount(rs.getInt(2));
		coil.setDate(rs.getString(1));
		return coil;
	}

}

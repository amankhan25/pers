package com.spring.test.dao;

import java.util.List;

import com.spring.entities.Slab;

public interface SlabDao {
	public List<Slab> slabDate();
}

package com.spring.taskdemo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.spring.entities.Coil;
import com.spring.entities.Slab;
import com.spring.test.dao.CoilDao;
import com.spring.test.dao.SlabDao;

@Controller
public class DemoController {
	@Autowired
	CoilDao coilDao;
	@Autowired
	SlabDao slabDao;
	
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		System.out.println("Program Strated...");
//		
//		ApplicationContext context=new ClassPathXmlApplicationContext("com/spring/taskdemo/config.xml");
//		CoilDao coilDao = context.getBean("coilDao", CoilDao.class);
//		Coil coil = coilDao.coilSource();
//		System.out.println(coil);
//		
//
//	}
	@RequestMapping("/coilsource")    
    public ModelAndView viewCoil() {
		System.out.println("This is viewCoil DemoController");
		Coil coilSource = coilDao.coilSource();
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("invSource",coilSource.getInventorySource());
		modelAndView.addObject("count",coilSource.getCount());
		modelAndView.setViewName("coil");
		return modelAndView;
	}
	@RequestMapping("/coildate")
	public ModelAndView viewDateCoil() {
		System.out.println("This is coil data date wise");
		List<Coil> coilDateList = coilDao.coilDate();
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("coilDateList",coilDateList);
		modelAndView.setViewName("coilDate");
		return modelAndView;
	}
	@RequestMapping("/slabdate")
	public ModelAndView viewDateSlab() {
		System.out.println("This is Slab Data Date Wise");
		List<Slab> slabDateList = slabDao.slabDate();
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("slabDateList",slabDateList);
		modelAndView.setViewName("slabDate");
		return modelAndView;
	}

}
